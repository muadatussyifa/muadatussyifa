const C = {cadmium:'#ED872D', sunset:'#FD5E53', light:'#FFB766', bisque:'#FFE4C4', ink:'#4A2410'};
Chart.defaults.color = C.ink;
Chart.defaults.font.family = '"Segoe UI", system-ui, sans-serif';
const $ = s => document.querySelector(s);
const fmt = (v, d = 2) => v == null ? '-' : Number(v).toLocaleString('id-ID', {maximumFractionDigits: d});
let D = null, charts = {}, ready = false;

function draw(id, cfg) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart($('#' + id), cfg);
}
const label = k => D.columns.find(c => c.key === k).label;

async function load() {
  const q = new URLSearchParams({gender: $('#fGender').value, age: $('#fAge').value});
  D = await (await fetch('/api/summary?' + q)).json();
  const err = $('#err');
  if (D.error) { err.textContent = D.error; err.hidden = false; return; }
  err.hidden = true;
  if (!ready) initSelects();
  render();
}

function initSelects() {
  const opts = D.columns.map(c => `<option value="${c.key}">${c.label}</option>`).join('');
  ['selHist', 'selX', 'selY'].forEach(id => $('#' + id).innerHTML = opts);
  $('#selHist').value = 'Exam_Score'; $('#selX').value = 'Study_Hours'; $('#selY').value = 'Exam_Score';
  $('#selHist').onchange = renderHist; $('#selX').onchange = $('#selY').onchange = renderScatter;
  ready = true;
}

function render() { renderKpis(); renderTable(); renderHist(); renderCat(); renderScatter(); renderGender(); renderHeat(); }

function renderKpis() {
  const s = D.stats;
  const items = [
    ['Jumlah Mahasiswa', D.n, `${D.gender_n.F || 0} F / ${D.gender_n.M || 0} M`],
    ['Rata-rata Nilai Ujian', fmt(s.Exam_Score.mean), `SD ${fmt(s.Exam_Score.std)}`],
    ['Rata-rata Kehadiran', fmt(s.Attendance.mean) + '%', `SD ${fmt(s.Attendance.std)}`],
    ['Rata-rata Jam Belajar', fmt(s.Study_Hours.mean), `SD ${fmt(s.Study_Hours.std)}`],
    ['Rata-rata Kepuasan', fmt(s.Satisfaction.mean), `SD ${fmt(s.Satisfaction.std)}`],
  ];
  $('#kpis').innerHTML = items.map(([t, v, sub]) =>
    `<div class="kpi"><small>${t}</small><b>${v}</b><small>${sub}</small></div>`).join('');
}

function renderTable() {
  const cols = [['count','N',0],['mean','Mean'],['median','Median'],['mode','Modus'],['std','Std'],
    ['min','Min'],['q1','Q1'],['q3','Q3'],['max','Max'],['iqr','IQR'],['cv','CV (%)',1],['skew','Skew'],['outliers','Outlier',0]];
  const head = '<thead><tr><th>Variabel</th>' + cols.map(c => `<th>${c[1]}</th>`).join('') + '</tr></thead>';
  const body = D.columns.map(({key, label}) => {
    const s = D.stats[key];
    const tds = cols.map(([k, , d]) => {
      if (k === 'mode') return `<td>${s.mode.map(m => fmt(m)).join(', ')}${s.mode_n > 3 ? '…' : ''}</td>`;
      return `<td>${fmt(s[k], d ?? 2)}</td>`;
    }).join('');
    return `<tr><td>${label}</td>${tds}</tr>`;
  }).join('');
  $('#tbl').innerHTML = head + '<tbody>' + body + '</tbody>';
}

function renderHist() {
  const k = $('#selHist').value, h = D.hist[k];
  draw('cHist', {type: 'bar',
    data: {labels: h.labels, datasets: [{label: 'Frekuensi', data: h.counts,
      backgroundColor: C.cadmium, hoverBackgroundColor: C.sunset, borderRadius: 6}]},
    options: {plugins: {legend: {display: false},
      title: {display: true, text: `${label(k)}  |  mean ${fmt(D.stats[k].mean)}, median ${fmt(D.stats[k].median)}`}},
      scales: {y: {beginAtZero: true, ticks: {precision: 0}, grid: {color: C.bisque}}, x: {grid: {display: false}}}}});
}

function renderCat() {
  draw('cCat', {type: 'doughnut',
    data: {labels: D.categories.labels, datasets: [{data: D.categories.counts,
      backgroundColor: [C.sunset, C.cadmium, C.light, '#FFD9A8', C.bisque], borderColor: '#FFF4E6', borderWidth: 3}]},
    options: {cutout: '55%', plugins: {legend: {position: 'bottom'}}}});
}

function renderScatter() {
  const x = $('#selX').value, y = $('#selY').value;
  const mk = g => D.points.filter(p => p.Gender === g).map(p => ({x: p[x], y: p[y]}));
  const xs = D.points.map(p => p[x]), ys = D.points.map(p => p[y]), n = xs.length;
  const mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n;
  let sxy = 0, sxx = 0, syy = 0;
  xs.forEach((v, i) => { sxy += (v - mx) * (ys[i] - my); sxx += (v - mx) ** 2; syy += (ys[i] - my) ** 2; });
  const b = sxx ? sxy / sxx : 0, a = my - b * mx, rr = sxx && syy ? sxy / Math.sqrt(sxx * syy) : 0;
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  draw('cScatter', {type: 'scatter',
    data: {datasets: [
      {label: 'Perempuan (F)', data: mk('F'), backgroundColor: C.sunset, pointRadius: 5},
      {label: 'Laki-laki (M)', data: mk('M'), backgroundColor: C.cadmium, pointRadius: 5},
      {type: 'line', label: 'Garis regresi', data: [{x: x0, y: a + b * x0}, {x: x1, y: a + b * x1}],
        borderColor: C.ink, borderDash: [6, 4], pointRadius: 0, borderWidth: 2}]},
    options: {plugins: {legend: {position: 'bottom'}},
      scales: {x: {title: {display: true, text: label(x)}, grid: {color: C.bisque}},
               y: {title: {display: true, text: label(y)}, grid: {color: C.bisque}}}}});
  $('#regInfo').textContent = x === y ? '' :
    `r = ${fmt(rr)}  |  y = ${fmt(a)} ${b < 0 ? '-' : '+'} ${fmt(Math.abs(b))}x  |  R² = ${fmt(rr * rr)}`;
}

function renderGender() {
  const groups = Object.keys(D.gender);
  $('#genderBars').innerHTML = groups.length < 2
    ? '<p class="note">Pilih "Semua" pada filter gender untuk membandingkan.</p>'
    : D.columns.map(({key, label}) => {
        const max = Math.max(...groups.map(g => D.gender[g][key]));
        const bars = groups.map(g => `<div class="bar"><span>${g}</span>
          <i class="${g}" style="width:${D.gender[g][key] / max * 70}%"></i>${fmt(D.gender[g][key])}</div>`).join('');
        return `<div class="item"><div class="name">${label}</div>${bars}</div>`;
      }).join('');
}

function renderHeat() {
  const k = D.columns.length;
  const el = $('#heat');
  el.style.gridTemplateColumns = `110px repeat(${k}, 1fr)`;
  let html = '<div></div>' + D.columns.map(c => `<div class="hc hh">${c.label}</div>`).join('');
  D.corr.forEach((row, i) => {
    html += `<div class="hc hh" style="text-align:left">${D.columns[i].label}</div>`;
    row.forEach(v => {
      const bg = v == null ? 'transparent' :
        `rgba(${v >= 0 ? '237,135,45' : '253,94,83'},${Math.min(Math.abs(v), 1) * 0.9 + 0.06})`;
      html += `<div class="hc" style="background:${bg}">${fmt(v)}</div>`;
    });
  });
  el.innerHTML = html;
}

$('#fGender').onchange = $('#fAge').onchange = load;
load();
