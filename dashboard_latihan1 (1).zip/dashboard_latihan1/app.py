from pathlib import Path
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

BASE = Path(__file__).resolve().parent
app = Flask(__name__)

LABELS = {
    "Age": "Usia", "Study_Hours": "Jam Belajar", "Sleep_Hours": "Jam Tidur",
    "Attendance": "Kehadiran (%)", "Exam_Score": "Nilai Ujian",
    "Monthly_Spending": "Pengeluaran Bulanan", "Screen_Hours": "Jam Layar",
    "Satisfaction": "Kepuasan (1-10)",
}
NUM = list(LABELS)


def r(x, nd=3):
    """Ubah angka numpy/NaN menjadi tipe JSON yang aman."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    return round(float(x), nd)


def describe(s):
    q1, q3 = s.quantile([.25, .75])
    iqr = q3 - q1
    modes = s.mode().tolist()
    return dict(
        count=int(s.count()), mean=r(s.mean()), median=r(s.median()),
        mode=[r(m, 2) for m in modes[:3]], mode_n=len(modes),
        std=r(s.std()), var=r(s.var()), min=r(s.min()), q1=r(q1), q3=r(q3),
        max=r(s.max()), range=r(s.max() - s.min()), iqr=r(iqr),
        cv=r(s.std() / s.mean() * 100 if s.mean() else None, 1),
        skew=r(s.skew()), kurt=r(s.kurt()),
        outliers=int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum()),
    )


def histogram(s):
    if s.nunique() <= 10:  # variabel diskret (Usia, Kepuasan)
        vc = s.value_counts().sort_index()
        return dict(labels=[str(int(i)) for i in vc.index], counts=vc.tolist())
    counts, edges = np.histogram(s, bins=8)
    labels = [f"{edges[i]:.1f}-{edges[i+1]:.1f}" for i in range(len(counts))]
    return dict(labels=labels, counts=counts.tolist())


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/summary")
def summary():
    df = pd.read_csv(BASE / "data" / "latihan1.csv")
    g, a = request.args.get("gender", "all"), request.args.get("age", "all")
    if g in ("F", "M"):
        df = df[df.Gender == g]
    if a.isdigit():
        df = df[df.Age == int(a)]
    if len(df) < 2:
        return jsonify(error="Data terlalu sedikit untuk filter ini."), 200

    cats = pd.cut(df.Exam_Score, [-np.inf, 60, 70, 80, 90, np.inf], right=False,
                  labels=["< 60", "60-69", "70-79", "80-89", "90-100"])
    corr = df[NUM].corr()
    return jsonify(
        n=len(df),
        columns=[dict(key=k, label=v) for k, v in LABELS.items()],
        stats={k: describe(df[k]) for k in NUM},
        hist={k: histogram(df[k]) for k in NUM},
        gender={x: {k: r(v, 2) for k, v in grp[NUM].mean().items()}
                for x, grp in df.groupby("Gender")},
        gender_n=df.Gender.value_counts().to_dict(),
        corr=[[r(corr.loc[i, j], 2) for j in NUM] for i in NUM],
        categories=dict(labels=cats.cat.categories.tolist(),
                        counts=cats.value_counts().sort_index().tolist()),
        points=df[["Gender"] + NUM].to_dict("records"),
    )


if __name__ == "__main__":
    app.run(debug=True)
